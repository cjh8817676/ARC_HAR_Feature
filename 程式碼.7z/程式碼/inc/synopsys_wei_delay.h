#ifndef ARC_DELAY_H
#define ARC_DELAY_H

#include "hx_drv_tflm.h"
#define CPU_CLK 400000000

void hal_delay_ms(unsigned int input_ms);

#endif /* ARC_DELAY_H */


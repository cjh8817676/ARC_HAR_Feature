/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "main_functions.h"
#include "hx_drv_tflm.h"
#include "synopsys_wei_delay.h"
// This is the default main used on systems that have the standard C entry
// point. Other devices (for example FreeRTOS or ESP32) that have different
// requirements for entry code (like an app_main function) should specialize
// this main.cc file in a target-specific subfolder.
volatile void delay_ms(unsigned int ms)
{
  volatile unsigned int delay_i = 0;
  volatile unsigned int delay_j = 0;
  volatile const unsigned int delay_cnt = 20000;

  for(delay_i = 0; delay_i < ms; delay_i ++)
    for(delay_j = 0; delay_j < delay_cnt; delay_j ++);
} 
union float_c{
  float m_float;
  uint8_t m_bytes[sizeof(float)];
};
union int_c{
  float m_int;
  uint8_t m_bytes[sizeof(int)];
};
union float_c myfloat;
union int_c myint;
int main(int argc, char* argv[]) {
  setup();
  while (true) {
    uint8_t oled_i = 0;
  uint32_t msec = 0;
  uint32_t sec = 0;
  hx_drv_uart_initial(UART_BR_115200);
  hx_drv_uart_print("URAT_GET_STRING_START\n");
  hx_drv_share_switch(SHARE_MODE_I2CM);
  uint8_t status;
  uint8_t data_write[2];
  uint8_t data_write1[2];
  uint8_t data_read[2];

  uint8_t read[2];
  data_write[0] = 0xbc;
  data_write[1] = 0xff;
  data_write1[0] = 0xff;
  data_write1[1] = 0xff;
  data_read[0]=0xBD;
  data_write1[0] = 0x0d;
  data_write1[1] = (0x1)<<2;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1,2); 
  if(status==0){
    hx_drv_uart_print("1");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x08;
  data_write1[1] = 0x0f;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x09;
  data_write1[1] = (1<<4)|2;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x0a;
  data_write1[1] = 9;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x14;
  data_write1[1] = 1|(1<<2);
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x11;
  data_write1[1] = 25;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x12;
  data_write1[1] = 25;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x0e;
  data_write1[1] = 6<<2;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x0f;
  data_write1[1] = 0;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x3c;
  data_write1[1] = 2;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");
  data_write1[0] = 0x3e;
  data_write1[1] = 0;
  status=hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 2); 
  if(status==0){
    hx_drv_uart_print("2");
  }
  else hx_drv_uart_print("fail");

  uint8_t buf[9];
  uint8_t b1,b2,b3,b4,b5,b6,b7,b8,b9;
  uint32_t elem[4];
  uint8_t tran[3];
  float ecg_data[960];
  uint8_t get_ch = 0;
  while(1){   
    if(hx_drv_uart_getchar(&get_ch) == HX_DRV_LIB_PASS){
        if(get_ch=='s'){
           break;
      }
    }
    
  }
  int count=0;
  while(1){
    if(count==960){
      break;
    }
    else{
      data_write1[0] = 0x07;
      data_write1[1] = 0;
      if(hx_drv_i2cm_set_data(0x5e, data_write, 0, data_write1, 1)==0){
        hx_drv_i2cm_get_data(0x5e, data_write, 0, buf, 9);
        b1=buf[0];
        b2=buf[1];
        b3=buf[2];
        b4=buf[3];
        b5=buf[4];
        b6=buf[5];
        b7=buf[6];
        b8=buf[7];
        b9=buf[8];
        /*hx_drv_uart_print("%c",b1);
        hx_drv_uart_print("%c",b2);
        hx_drv_uart_print("%c",b3);
        hx_drv_uart_print("%c",b4);
        hx_drv_uart_print("%c",b5);
        hx_drv_uart_print("%c",b6);
        hx_drv_uart_print("%c",b7);
        hx_drv_uart_print("%c",b8);
        hx_drv_uart_print("%c",b9);*/
        
        elem[0]=((buf[0]<<16)|(buf[1]<<8)|buf[2])&0x07ffff;
        elem[1]=((buf[3]<<16)|(buf[4]<<8)|buf[5])&0x07ffff;
        elem[2]=((buf[6]<<16)|(buf[7]<<8)|buf[8])&0x03ffff;
        /*for(int i=0;i<3;i++){
          tran[0]=elem[i]&0xff;
          tran[1]=(elem[i]>>8)&0xff;
          tran[2]=(elem[i]>>16)&0xff;
          hx_drv_uart_print("%c",tran[0]);
          hx_drv_uart_print("%c",tran[1]);
          hx_drv_uart_print("%c",tran[2]);
        }*/
        ecg_data[count]=(float)elem[2];
        count=count+1;
      }
    }
    delay_ms(3);
  }
    
    loop(ecg_data);
    //delay_ms(5000);
  }
}

/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/version.h"

#include "hx_drv_tflm.h"
#include "synopsys_wei_delay.h"
#include "synopsys_wei_gpio.h"
#include "main_functions.h"
#include "detection_responder.h"
#include "image_provider.h"
#include "model_settings.h"
#include "model.h"
#include "test_samples.h"

// Globals, used for compatibility with Arduino-style sketches.
namespace {
tflite::ErrorReporter* error_reporter = nullptr;
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;
union float_c{
  float m_float;
  uint8_t m_bytes[sizeof(float)];
};
union int_c{
  float m_int;
  uint8_t m_bytes[sizeof(int)];
};
union float_c myfloat;
union int_c myint;
// In order to use optimized tensorflow lite kernels, a signed int8_t quantized
// model is preferred over the legacy unsigned model format. This means that
// throughout this project, input images must be converted from unisgned to
// signed format. The easiest and quickest way to convert from unsigned to
// signed 8-bit integers is to subtract 128 from the unsigned value to get a
// signed value.

// An area of memory to use for input, output, and intermediate arrays.
constexpr int kTensorArenaSize = 200 * 1024;
alignas(16) uint8_t tensor_arena[kTensorArenaSize] = {0};
}  // namespace


volatile void delay_ms(unsigned int ms);

// The name of this function is important for Arduino compatibility.
void setup() {
  // Set up logging. Google style is to avoid globals or statics because of
  // lifetime uncertainty, but since this has a trivial destructor it's okay.
  // NOLINTNEXTLINE(runtime-global-variables)
  
  static tflite::MicroErrorReporter micro_error_reporter;
  error_reporter = &micro_error_reporter;

  // Map the model into a usable data structure. This doesn't involve any
  // copying or parsing, it's a very lightweight operation.
  model = tflite::GetModel(my_ecg_model_tflite);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    TF_LITE_REPORT_ERROR(error_reporter,
                         "Model provided is schema version %d not equal "
                         "to supported version %d.",
                         model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }

  // Pull in only the operation implementations we need.
  // This relies on a complete list of all the ops needed by this graph.
  // An easier approach is to just use the AllOpsResolver, but this will
  // incur some penalty in code space for op implementations that are not
  // needed by this graph.
  //
  // tflite::AllOpsResolver resolver;
  // NOLINTNEXTLINE(runtime-global-variables)
  
  static tflite::MicroMutableOpResolver<6> micro_op_resolver;
  micro_op_resolver.AddConv2D();
  micro_op_resolver.AddMaxPool2D();
  micro_op_resolver.AddFullyConnected();
  micro_op_resolver.AddReshape();
  micro_op_resolver.AddSoftmax();
  micro_op_resolver.AddQuantize();
  // Build an interpreter to run the model with.
  // NOLINTNEXTLINE(runtime-global-variables)
  static tflite::MicroInterpreter static_interpreter(
      model, micro_op_resolver, tensor_arena, kTensorArenaSize, error_reporter);
  interpreter = &static_interpreter;

  // Allocate memory from the tensor_arena for the model's tensors.
  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter, "AllocateTensors() failed");
    return;
  }

  // Get information about the memory area to use for the model's input.
  input = interpreter->input(0);
  output = interpreter->output(0);

  // Obtain quantization parameters for result dequantization
}

// The name of this function is important for Arduino compatibility.
void loop(float* ecg_data) {

  int32_t test_cnt = 0;
  int32_t correct_cnt = 0;

  float scale = input->params.scale;
  int32_t zero_point = input->params.zero_point;
  uint32_t sec = 0;
  hx_drv_uart_initial(UART_BR_115200);
  float max_r=0;
  float ecg_diff[960];
  float heart[300][4];
  int r_peak_save;
  int r_peak[5];
  for(int i=1;i<960;i++){
  	if(max_r<ecg_data[i])max_r=ecg_data[i];
  }
  for(int i=1;i<960;i++){
  	ecg_data[i]=-(ecg_data[i]-max_r);
  }
  for(int i=1;i<959;i++){
  	ecg_diff[i-1]=ecg_data[i]-ecg_data[i-1];
  }
  float avg=0;
  avg=ecg_data[0];
  for(int i=1;i<960;i++){
  	avg=ecg_data[i]+avg;
  }
  avg=avg/960;
  for(int i=0;i<960;i++){
  	ecg_data[i]=ecg_data[i]-avg;
  }
  float min=99999;
  for(int i=0;i<960;i++){
  	if(min>ecg_data[i]){
  		min=ecg_data[i];
  	}
  }
  for(int i=0;i<960;i++){
  		ecg_data[i]=ecg_data[i]-min;
  }
  
  int peak_count=0;
  for(int i=0;i<960;i++){
  	max_r=0;
  	for(int k=0;k<399;k++){
  		if(max_r<ecg_diff[i+k]){
  			max_r=ecg_diff[i+k];
  			r_peak_save=i+k;
  		}
  	}
  	i=r_peak_save+100;

  	r_peak[peak_count]=r_peak_save;
  	peak_count++;
  	if((i+399)>960)break;
  }
  for(int i=0;i<peak_count;i++){
  	for(int j=0;j<128;j++){
  		heart[j][i]=ecg_data[(r_peak[i]-64+j)];
  	}
  	
  }
  float max_data=-50000;
  for(int i=0;i<peak_count;i++){
  	avg=0;
  	for(int j=0;j<128;j++){
	  	avg=heart[j][i]+avg;
  	}
  	avg=avg/128;
  	for(int j=0;j<128;j++){
	  	heart[j][i]=heart[j][i]-avg;
  	}
  }
  for(int i=0;i<peak_count;i++){
  	min=99999;
  	for(int j=0;j<128;j++){
  		if(heart[j][i]<min){
  			min=heart[j][i];
  		}
	  	
  	}
  	for(int j=0;j<128;j++){
	  	heart[j][i]=heart[j][i]-min;
  	}
  }
  for(int i=0;i<peak_count;i++){
  	max_data=-50000;
  	for(int j=0;j<128;j++){
	  	if(heart[j][i]>max_data){
	  		max_data=heart[j][i];
	  	}
  	}
  	for(int j=0;j<128;j++){
	  	heart[j][i]=heart[j][i]/max_data;
  	}
  }
  for(int i=0;i<960;i++){
      myfloat.m_float=ecg_data[i];
      hx_drv_uart_print("c");
      hx_drv_uart_print("%c",myfloat.m_bytes[0]);
      hx_drv_uart_print("%c",myfloat.m_bytes[1]);
      hx_drv_uart_print("%c",myfloat.m_bytes[2]);
      hx_drv_uart_print("%c",myfloat.m_bytes[3]);
    }
  hx_drv_uart_print("p");
  myint.m_int=peak_count;
  hx_drv_uart_print("%c",myint.m_bytes[3]);
  hx_drv_uart_print("%c",myint.m_bytes[2]);
  hx_drv_uart_print("%c",myint.m_bytes[1]);
  hx_drv_uart_print("%c",myint.m_bytes[0]);
  for(int k=0;k<128;k++){
      myfloat.m_float=heart[k][1];
      hx_drv_uart_print("c");
      hx_drv_uart_print("%c",myfloat.m_bytes[0]);
      hx_drv_uart_print("%c",myfloat.m_bytes[1]);
      hx_drv_uart_print("%c",myfloat.m_bytes[2]);
      hx_drv_uart_print("%c",myfloat.m_bytes[3]);
   }
   uint8_t get_ch;
   while(1){
	  if(hx_drv_uart_getchar(&get_ch) == HX_DRV_LIB_PASS){
	           break;
	    }
   }
  // Invoke interpreter for each test sample and process results
  /*for (int j = 0; j < kNumSamples; j++) 
  {

    //TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Reading and round values to either -128 or 127\n", j);
    // Perform image thinning (round values to either -128 or 127)
    // Write image to input data
    for (int i = 0; i < kImageSize; i++) {
      input->data.f[i] = test_samples[j].image[i];
    }

    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Invoking\n", peak_count);
    // Run the model on this input and make sure it succeeds.
    if (kTfLiteOk != interpreter->Invoke()) {
      TF_LITE_REPORT_ERROR(error_reporter, "Invoke failed.");
    }
  
    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Finding Max Value\n", j);
    // Get max result from output array and calculate confidence
    int8_t* results_ptr = output->data.int8;
    int result = std::distance(results_ptr, std::max_element(results_ptr, results_ptr + 8));
    float confidence = ((results_ptr[result] - zero_point)*scale + 1) / 2;
    const char *status = result == test_samples[j].label ? "SUCCESS" : "FAIL";

    if(result == test_samples[j].label)
      correct_cnt ++;
    test_cnt ++;

    TF_LITE_REPORT_ERROR(error_reporter, 
      "Test sample \"%s\":\n"
      "Predicted %s (%d%%) - %s\n",
      kCategoryLabels[test_samples[j].label], 
      kCategoryLabels[result], (int)(confidence * 100), status);


    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Reading\n", j);
    // Write image to input data
    for (int i = 0; i < kImageSize; i++) {
      input->data.f[i] = test_samples[j].image[i];
    }

    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Invoking\n", j);
    // Run the model on this input and make sure it succeeds.
    if (kTfLiteOk != interpreter->Invoke()) {
      TF_LITE_REPORT_ERROR(error_reporter, "Invoke failed.");
    }
  
    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Start Finding Max Value\n", j);
    // Get max result from output array and calculate confidence
    int8_t*results_ptr1 = output->data.int8;
    result = std::distance(results_ptr1, std::max_element(results_ptr1, results_ptr1 + 8));
    confidence = ((results_ptr1[result] - zero_point)*scale + 1) / 2;
    status = result == test_samples[j].label ? "SUCCESS" : "FAIL";

    if(result == test_samples[j].label)
      correct_cnt ++;
    test_cnt ++;

    TF_LITE_REPORT_ERROR(error_reporter, 
      "Test sample \"%s\":\n"
      "Predicted %s (%d%%) - %s\n",
      kCategoryLabels[test_samples[j].label], 
      kCategoryLabels[result], (int)(confidence * 100), status);      
      
    TF_LITE_REPORT_ERROR(error_reporter, "Test sample[%d] Finsih\n\n", j);
  }
  

  TF_LITE_REPORT_ERROR(error_reporter, "Correct Rate = %d / %d\n\n", correct_cnt, test_cnt);*/
 // while(1);
  for(int i=0;i<1;i++){
	  for (int j = 0; j < 128; j++) {
	      input->data.f[j] = heart[j][i];
	  }

    //TF_LITE_REPORT_ERROR(error_reporter,"Start Invoking  ");
    // Run the model on this input and make sure it succeeds.
    if (kTfLiteOk != interpreter->Invoke()) {
      TF_LITE_REPORT_ERROR(error_reporter, "Invoke failed.");
    }
  
    //TF_LITE_REPORT_ERROR(error_reporter, "Start Finding Max Value  ");
    // Get max result from output array and calculate confidence
    int8_t* results_ptr = output->data.int8;
    int result = std::distance(results_ptr, std::max_element(results_ptr, results_ptr + 8));
    float confidence = ((results_ptr[result] - zero_point)*scale + 1) / 2;

    TF_LITE_REPORT_ERROR(error_reporter, 
      "Predicted V ",
      get_ch);
	}
	
}

